const db = require('../db');

exports.searchRecipes = (req, res) => {
  const searchTerm = req.query.searchTerm;  // Get search term from query parameters

  const sql = 'SELECT * FROM recipes WHERE title LIKE ? OR ingredients LIKE ?';
  db.query(sql, [`%${searchTerm}%`, `%${searchTerm}%`], (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Error fetching recipes' });
    }
    res.json(results);
  });
};
