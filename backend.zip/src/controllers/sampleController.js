// const db = require('../config');

// const getSampleData = (req, res) => {
//     db.query('SELECT * FROM sample_table', (err, results) => {
//         if (err) {
//             console.error('Error executing query:', err.message);
//             res.status(500).json({ error: 'Database query failed' });
//         } else {
//             res.json(results);
//         }
//     });
// };

// module.exports = { getSampleData };