// const WellnessPlan = require('../models/wellnessPlan');

// exports.getPlans = (req, res) => {
//   const userId = req.user.id; // Extracted from JWT token

//   WellnessPlan.getPlans(userId, (err, results) => {
//     if (err) {
//       res.status(500).json({ message: 'Error fetching plans' });
//     } else {
//       res.status(200).json({ plans: results });
//     }
//   });
// };



// src/controllers/wellnessPlanController.js
const db = require('../db')
exports.getWellnessPlan = (req, res) => {
  try{
  const wellnessPlan = {
    dailyGoals: ["Drink 2 liters of water", "Take a 30-minute walk", "Meditate for 10 minutes"],
    mealPlan: [
      { name: "Breakfast", description: "Oatmeal with fresh fruit" },
      { name: "Lunch", description: "Grilled chicken salad with olive oil dressing" },
      { name: "Dinner", description: "Baked salmon with quinoa and steamed veggies" }
    ],
    workouts: [
      { name: "Morning Yoga", duration: 20 },
      { name: "Evening Cardio", duration: 30 }
    ],
    mentalHealthTips: ["Practice gratitude journaling", "Limit screen time before bed", "Connect with a friend or family member"]
  };

  res.json(wellnessPlan);
}catch (error) {
  console.error("Error in getWellnessPlan:", error);
  res.status(500).json({ message: "Failed to fetch wellness plan" });
}
};
