// const mysql = require('mysql2');
// require('dotenv').config();

// const db = mysql.createPool({
//   host: process.env.DB_HOST,
//   user: process.env.DB_USER,
//   password: process.env.DB_PASSWORD,
//   database: process.env.DB_NAME,
// });

// db.getConnection((err) => {
//   if (err) {
//     console.error('Database connection failed:', err.message);
//   } else {
//     console.log('Connected to the database.');
//   }
// });

// module.exports = db;

// !---------------------
const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'aishu@05',
  database: 'backend_bloom',
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL database');
});

module.exports = db;
