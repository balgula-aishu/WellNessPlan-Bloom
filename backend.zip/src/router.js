// const express = require('express');
// const { getSampleData } = require('./controllers/sampleController');

// const router = express.Router();

// // Define routes
// router.get('/sample', getSampleData);

// module.exports = router;