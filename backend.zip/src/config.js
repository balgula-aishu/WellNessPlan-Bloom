// const mysql = require('mysql2');

// // Create the connection pool
// const pool = mysql.createPool({
//     host: 'localhost',
//     user: 'root',
//     password: 'aishu@05', // Replace with your MySQL password
//     database: 'backend_bloom', // Replace with your database name
//     waitForConnections: true,
//     connectionLimit: 10,
//     queueLimit: 0
// });

// // Test the connection
// pool.getConnection((err, connection) => {
//     if (err) {
//         console.error('Error connecting to the database:', err.message);
//     } else {
//         console.log('Connected to the MySQL database');
//         connection.release(); // Release the connection back to the pool
//     }
// });

// module.exports = pool;