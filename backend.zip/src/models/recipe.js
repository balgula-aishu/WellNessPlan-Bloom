const db = require('../db');

const WellnessPlan = {
  getPlans: (userId, callback) => {
    const sql = 'SELECT * FROM recipes WHERE user_id = ?';
    db.query(sql, [userId], callback);
  },
};

module.exports = WellnessPlan;