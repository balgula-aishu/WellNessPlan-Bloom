// const express = require('express');
// const router = require('./router');
// const db = require('./config'); // Ensures DB connection

// const app = express();

// // Middleware
// app.use(express.json());

// // Routes
// app.use('/api', router);

// module.exports = app;