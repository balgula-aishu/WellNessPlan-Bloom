// src/routes/wellnessPlanRoutes.js

const express = require('express');
const wellnessPlanController = require('../controllers/wellnessPlanController');  // Ensure this path is correct
const router = express.Router();

// Define the GET route for /api/wellness-plan
router.get('/wellness-plan', wellnessPlanController.getWellnessPlan);

module.exports = router;


