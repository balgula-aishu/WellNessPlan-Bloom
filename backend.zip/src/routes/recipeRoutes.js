const express = require('express');
const recipeController = require('../controllers/recipeController');
const router = express.Router();

// Search recipes route
router.get('/search-recipes', recipeController.searchRecipes);

module.exports = router;
