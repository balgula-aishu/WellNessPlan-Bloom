// src/routes/authRoutes.js
const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Define the correct route for the register/signup endpoint
router.post('/register', authController.register);  // Ensure the route is "/register"
router.post('/login', authController.login);

module.exports = router;


