const express = require('express');
const cors = require('cors');
// const mysql = require('mysql2');
const bodyParser = require('body-parser');
const authRoutes = require('./src/routes/authRoutes');
// const server = require('./server');  // Ensure the relative path is correct

const wellnessPlanRoutes = require('./src/routes/wellnessPlanRoutes');
const recipeRoutes = require('./src/routes/recipeRoutes');
const dotenv = require('dotenv');

// Initialize dotenv for environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api', wellnessPlanRoutes);
app.use('/api', recipeRoutes);

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
// !---------------------------------------

// const express = require('express');
// const cors = require('cors');
// const dotenv = require('dotenv');
// const mysql = require('mysql2');

// dotenv.config();

// const app = express();
// app.use(express.json());
// app.use(cors());

// // MySQL database connection
// const db = mysql.createConnection({
//   host: process.env.DB_HOST,
//   user: process.env.DB_USER,
//   password: process.env.DB_PASSWORD,
//   database: process.env.DB_NAME
// });

// db.connect((err) => {
//   if (err) {
//     console.error('Database connection failed:', err.stack);
//     return;
//   }
//   console.log('Connected to MySQL database');
// });

// // Basic route
// app.get('/', (req, res) => {
//   res.send('Hello, World!');
// });

// // Server setup
// const PORT = process.env.PORT || 5000;
// app.listen(PORT, () => {
//   console.log(`Server is running on port ${PORT}`);
// });
// !--------------------------
// Test route to verify the server is working

// const express = require('express');
// const cors = require('cors');
// const bodyParser = require('body-parser');
// const wellnessPlanRoutes = require('./src/routes/wellnessPlanRoutes'); // Correct path to routes

// const app = express(); // Ensure app is initialized

// app.use(cors());
// app.use(bodyParser.json());

// // Add test route
// app.get('/test', (req, res) => {
//   res.send('Server is working!');
// });

// // Register wellnessPlanRoutes for /api/wellness-plan
// app.use('/api/wellness-plan', wellnessPlanRoutes);

// const port = 5000;
// app.listen(port, () => {
//   console.log(`Server running on http://localhost:${port}`);
// });
