import React, { useEffect, useState } from 'react';
import axios from 'axios';

const WellnessPlan = () => {
  const [wellnessPlan, setWellnessPlan] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true); // Track loading state

  useEffect(() => {
    const fetchWellnessPlan = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/wellness-plan');
        setWellnessPlan(response.data);
        setError('');
      } catch (err) {
        console.error('Error fetching wellness plan:', err); // Log error details
        setError('Failed to load wellness plan. Please try again later.');
      } finally {
        setLoading(false); // Stop loading after fetch attempt
      }
    };

    fetchWellnessPlan();
  }, []);

  if (loading) {
    return <p>Loading wellness plan...</p>; // Show loading state
  }

  return (
    <div>
      <h2>Wellness Plan</h2>
      {error ? (
        <p style={{ color: 'red' }}>{error}</p>
      ) : (
        wellnessPlan && (
          <div>
            <h3>Daily Goals</h3>
            <ul>
              {wellnessPlan.dailyGoals.map((goal, index) => (
                <li key={index}>{goal}</li>
              ))}
            </ul>

            <h3>Meal Plan</h3>
            <ul>
              {wellnessPlan.mealPlan.map((meal, index) => (
                <li key={index}>
                  <strong>{meal.name}:</strong> {meal.description}
                </li>
              ))}
            </ul>

            <h3>Workouts</h3>
            <ul>
              {wellnessPlan.workouts.map((workout, index) => (
                <li key={index}>
                  <strong>{workout.name}:</strong> {workout.duration} minutes
                </li>
              ))}
            </ul>

            <h3>Mental Health Tips</h3>
            <ul>
              {wellnessPlan.mentalHealthTips.map((tip, index) => (
                <li key={index}>{tip}</li>
              ))}
            </ul>
          </div>
        )
      )}
    </div>
  );
};

export default WellnessPlan;
