import React, { useState } from 'react'

const WorkoutTracker = () => {
    let[workouts,setWorkouts]=useState([])
    let[workoutName,setWorkoutName]=useState('')
    let[duration,setDuration]=useState('')
    let[date,setDate]=useState('')
    let[error,setError]=useState('')

    const handleAddWorkout = (e) => {
        e.preventDefault();

        if (!workoutName || !duration || !date) {
          setError('All fields are required.');
          return;
        }
    
        const newWorkout = {
          id: workouts.length + 1,
          name: workoutName,
          duration: `${duration} mins`,
          date,
        };
    
        setWorkouts([...workouts, newWorkout]);
        setWorkoutName('');
        setDuration('');
        setDate('');
        setError('');
      };
      const handleDelete = async (id) => {
        try {
          await axios.delete(`http://localhost:5000/api/workouts/${id}`);
      
          // Fetch updated workouts
          const response = await axios.get('http://localhost:5000/api/workouts', {
            headers: { Authorization: `Bearer ${token}`},});
          setWorkouts(response.data);
        } catch (err) {
          console.error('Error deleting workout:', err);
        }
      };

  return (
    <div className="workout-tracker">
      <h1>Workout Tracker</h1>
      <form onSubmit={handleAddWorkout} className="workout-form">
        <input
          type="text"
          placeholder="Workout Name (e.g., Morning Yoga)"
          value={workoutName}
          onChange={(e) => setWorkoutName(e.target.value)}
          className="input"
        />
        <input
          type="number"
          placeholder="Duration (in minutes)"
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
          className="input"
        />
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="input"
        />
        <button type="submit" className="add-button">
          Add Workout
        </button>
      </form>
      {error && <p className="error">{error}</p>}
      <div className="workout-history">
        <h2>Workout History</h2>
        {workouts.length > 0 ? (
          <ul>
            {workouts.map((workout) => (
              <li key={workout.id} className="workout-item">
                <strong>{workout.name}</strong> - {workout.duration} on {workout.date}
                <button onClick={() => handleDelete(workout.id)}>Delete</button>
              </li>
            ))}
          </ul>
        ) : (
          <p>No workouts logged yet. Start by adding a new workout!</p>
        )}
      </div>
    </div>
  );
}

export default WorkoutTracker
