import React, { useState } from 'react'
import axios from 'axios'
const RecipeSearch = () => {

    let[searchTerm,setSearchTerm]=useState('')
    let[recipes,setRecipes]=useState([])
    let[error,setError]=useState('')

    const handleSearch = async (e) => {
        e.preventDefault();
        setError('');
        try {
          const response = await axios.get(`http://localhost:5000/api/recipes?search=${searchTerm}`);
          setRecipes(response.data);
        } catch (err) {
          setError('Failed to fetch recipes. Please try again.');
        }
      };
  return (
    <div className="recipe-search">
      <h1>Recipe Search</h1>
      <form onSubmit={handleSearch}>
        <input
          type="text"
          placeholder="Search for a recipe..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-input"
        />
        <button type="submit" className="search-button">Search</button>
      </form>
      {error && <p className="error">{error}</p>}
      <div className="recipe-results">
        {recipes.length > 0 ? (
          recipes.map((recipe) => (
            <div key={recipe.id} className="recipe-card">
              <h2>{recipe.name}</h2>
              <p>{recipe.description}</p>
              <ul>
                {recipe.ingredients.map((ingredient, index) => (
                  <li key={index}>{ingredient}</li>
                ))}
              </ul>
              <p><strong>Instructions:</strong> {recipe.instructions}</p>
            </div>
          ))
        ) : (
          searchTerm && <p>No recipes found. Try a different search term.</p>
        )}
      </div>
    </div>
  );
}

export default RecipeSearch
