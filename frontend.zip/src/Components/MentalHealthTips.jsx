import React, { useEffect, useState } from 'react'

const MentalHealthTips = () => {
    let[tips,setTips]=useState([])
    let[newTip,setNewTip]=useState('')
    let[error,setError]=useState('')
    let[success,setSucess]=useState('')
    useEffect(() => {
        const fetchTips = async () => {
          try {
            const response = await axios.get('http://localhost:5000/api/mental-health-tips');
            setTips(response.data);
          } catch (err) {
            console.error('Error fetching tips:', err);
            setError('Failed to fetch mental health tips.');
          }
        };
    
        fetchTips();
      }, []);
      const handleAddTip = async (e) => {
        e.preventDefault();
    
        if (!newTip.trim()) {
          setError('Tip cannot be empty.');
          return;
        }
    
        try {
          const response = await axios.post('http://localhost:5000/api/mental-health-tips', { tip: newTip });
          setTips([...tips, response.data]);
          setNewTip('');
          setError('');
          setSuccess('Tip added successfully!');
          setTimeout(() => setSuccess(''), 3000); // Clear success message after 3 seconds
        } catch (err) {
          console.error('Error adding tip:', err);
          setError('Failed to add tip.');
        }
      };
  return (
    <div className="mental-health-tips-container">
      <h1>Mental Health Tips</h1>
      <ul className="tips-list">
        {tips.map((tip, index) => (
          <li key={index} className="tip-item">
            {tip.tip}
          </li>
        ))}
      </ul>
      <form onSubmit={handleAddTip} className="add-tip-form">
        <input
          type="text"
          value={newTip}
          onChange={(e) => setNewTip(e.target.value)}
          placeholder="Add a new tip"
          className="tip-input"
        />
        <button type="submit" className="add-tip-button">Add Tip</button>
      </form>
      {error && <p className="error-message">{error}</p>}
      {success && <p className="success-message">{success}</p>}
    </div>
  );
};

export default MentalHealthTips
