import React from 'react';
import { createBrowserRouter, RouterProvider, Navigate } from 'react-router-dom';
import Login from './Components/Login';
import SignUp from './Components/SignUp';
import MentalHealthTips from './Components/MentalHealthTips';
import RecipeSearch from './Components/RecipeSearch';
import WellnessPlan from './Components/WellnessPlan';
import WorkoutTracker from './Components/WorkoutTracker';
import PageNotFound from './Components/PageNotFound';
import './login.css'
// import './Style.css'
// import './WellnessPlan.css'
// import './RecipeSearch.css'
// import './WorkoutTracker.css'
// import './MentalHealthTips.css'

const App = () => {
  const routes = createBrowserRouter([
    {
      path: "/",
      element: <Navigate to="/login" replace />,
    },
    {
      path: "/login",
      element: <Login />,
    },
    {
      path: "/signup",
      element: <SignUp />,
    },
    {
      path: "/mentalhealthtips",
      element: <MentalHealthTips />,
    },
    {
      path: "/recipesearch",
      element: <RecipeSearch />,
    },
    {
      path: "/wellnessplan",
      element: <WellnessPlan />,
    },
    {
      path: "/workouttracker",
      element: <WorkoutTracker />,
    },
    {
      path: "*",
      element: <PageNotFound />,
    },
  ]);

  return (
    <>
      {/* <h1>WellNessBloom</h1> */}
      <RouterProvider router={routes} />
    </>
  );
};

export default App;